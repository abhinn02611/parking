import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-add-parking-details',
  templateUrl: './add-parking-details.component.html',
  styleUrls: ['./add-parking-details.component.css']
})
export class AddParkingDetailsComponent implements OnInit {
  @Input() editId = '';
  @Input() operator = null;
  @Input() parking_id = '';
  @Output() actionCancel = new EventEmitter();
  @Output() actionPrimary = new EventEmitter();
  @Output() actionSecondary = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }
  onCancel = () => {
    this.actionCancel.emit();
  };
  onPrimary = () => {
    this.saveRate(1);
  };
  saveRate(e){

  }
}
